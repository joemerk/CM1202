class testPassword{
	public static void main(String[] args) {
		LogIn test = new LogIn();
		test.changePassword();
		test.changePassword();
	}
}